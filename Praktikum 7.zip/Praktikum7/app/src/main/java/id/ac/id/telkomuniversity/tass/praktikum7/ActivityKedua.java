package id.ac.id.telkomuniversity.tass.praktikum7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ActivityKedua extends AppCompatActivity {
    TextView tvusername, tvpassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kedua);
        tvusername = (TextView) findViewById(R.id.tvUsername);
        tvpassword = (TextView) findViewById(R.id.tvPassword);

        tvusername.setText(getIntent().getStringExtra("username"));
        tvpassword.setText(getIntent().getStringExtra("password"));

    }
}