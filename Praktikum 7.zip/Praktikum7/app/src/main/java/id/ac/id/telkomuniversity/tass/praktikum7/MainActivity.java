package id.ac.id.telkomuniversity.tass.praktikum7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText username, password;
    Button btnlogin, btnForgetPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        btnlogin = (Button) findViewById(R.id.btnlogin);
        btnForgetPassword= (Button) findViewById(R.id.btnForgetPassword);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (username.getText().toString().equals("")){
                    username.setError("Username Tidak Boleh Kosong");
                }else if (password.getText().toString().equals("")){
                    password.setError("Password Tidak Boleh Kosong");
                }else{
                    String user = username.getText().toString();
                    String pass = password.getText().toString();

                    Toast.makeText(MainActivity.this, "Hai, "+user+" Password anda adalah " +pass, Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(MainActivity.this, ActivityKedua.class);
                    intent.putExtra("username", user);
                    intent.putExtra("password", pass);
                    startActivity(intent);
                }
            }
        });

        btnForgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    Intent intent = new Intent(MainActivity.this, ActivityKetiga.class);
                    startActivity(intent);
                }

        });

    }
}